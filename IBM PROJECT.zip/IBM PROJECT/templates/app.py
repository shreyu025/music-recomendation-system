from flask import Flask, render_template, request
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

#app 
app = Flask(__name__)

#routes
@app.route("/")
def index():
    return render_template('login.html')

#python app call
if __name__=="__main__":
    app.run(debug=True)
